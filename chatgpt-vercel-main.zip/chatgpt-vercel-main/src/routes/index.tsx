import Chat from "~/components/Chat"
import Layout from "~/layout"

export default function () {
  return (
    <Layout>
      <Chat />
    </Layout>
  )
}
